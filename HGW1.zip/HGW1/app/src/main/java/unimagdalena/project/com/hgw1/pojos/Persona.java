package unimagdalena.project.com.hgw1.pojos;

import android.os.Parcel;
import android.os.Parcelable;

public class Persona implements Parcelable{
    private String nombre;
    private String apellido;
    private String correo;
    private int telefono;

    public Persona(String nombre, String apellido, String correo, int telefono) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.correo = correo;
        this.telefono = telefono;
    }

    public Persona() {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }



    private Persona(Parcel in){
        this.nombre=in.readString();
        this.apellido=in.readString();
        this.correo=in.readString();
        this.telefono=in.readInt();
    }



    public static final Parcelable.Creator<Persona>CREATOR=new Creator<Persona>() {
        @Override
        public Persona createFromParcel(Parcel source) {
            return new Persona(source);
        }

        @Override
        public Persona[] newArray(int size) {
            return new Persona[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.nombre);
        dest.writeString(this.apellido);
        dest.writeString(this.correo);
        dest.writeInt(this.telefono);




    }
}
