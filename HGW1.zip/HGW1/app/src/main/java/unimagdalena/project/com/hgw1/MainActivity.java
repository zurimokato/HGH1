package unimagdalena.project.com.hgw1;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import unimagdalena.project.com.hgw1.pojos.Persona;

public class MainActivity extends AppCompatActivity {

    private Button btnBoton;
    private EditText nombreTxt;
    private EditText apellidoTxt;
    private EditText correoTxt;
    private EditText telefonoTxt;
    private Button btn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nombreTxt = (EditText) findViewById(R.id.txtNombre);
        apellidoTxt = (EditText) findViewById(R.id.txtApellido);
        correoTxt = (EditText) findViewById(R.id.TextEmail);
        telefonoTxt = (EditText) findViewById(R.id.TextTelefono);
        btnBoton = (Button) findViewById(R.id.btmEnviar);
        btn=(Button)findViewById(R.id.button2);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in=new Intent(MainActivity.this,Main3Activity.class);
                startActivity(in);
            }
        });

        btnBoton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nombre = nombreTxt.getText().toString();
                String apellido = apellidoTxt.getText().toString();
                String correo = correoTxt.getText().toString();
                int telefono = Integer.parseInt(telefonoTxt.getText().toString());

                Persona persona = new Persona(nombre,apellido,correo,telefono);


                Intent pasar = new Intent(MainActivity.this, MainActivity2.class);
                pasar.putExtra("persona", persona);
                startActivity(pasar);

            }
        });


    }
}












