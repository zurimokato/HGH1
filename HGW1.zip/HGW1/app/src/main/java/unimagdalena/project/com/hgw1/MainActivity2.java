package unimagdalena.project.com.hgw1;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import unimagdalena.project.com.hgw1.pojos.Persona;

public class MainActivity2 extends AppCompatActivity {


    private TextView textoPersona;
    private Button   botonRegresar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        textoPersona=(TextView)findViewById(R.id.datosPersona);

        botonRegresar=(Button)findViewById(R.id.btnRegresar);


        Persona persona=getIntent().getParcelableExtra("persona");
        textoPersona.setText("Nombre: "+persona.getNombre()+"\nApellido: "+persona.getApellido()+"\nCorreo: "+persona.getCorreo()+"\nTelefono: "+persona.getTelefono());

        botonRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent regresar=new Intent(MainActivity2.this,MainActivity.class);
                startActivity(regresar);
            }
        });



    }
}
